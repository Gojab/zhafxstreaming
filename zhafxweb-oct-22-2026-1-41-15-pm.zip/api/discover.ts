export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const isTrending = Boolean(
    req.query?.trending ||
    req.query?.action === 'trending' ||
    req.url?.includes('/trending')
  );

  const backends = ['https://api.framextv.cc', 'https://api.framextv.tech', 'https://api.framextv.xyz'];

  // Handle Trending Requests
  if (isTrending) {
    const page = (req.query.page as string) || '1';
    const type = req.query.type as string;
    const q = new URLSearchParams();
    q.set('page', page);
    if (type) q.set('type', type);

    for (const backend of backends) {
      try {
        const upstreamRes = await fetch(`${backend}/api/trending?${q.toString()}`, {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            Referer: 'https://framextv.cc/',
            Origin: 'https://framextv.cc',
            Accept: 'application/json',
          },
          signal: AbortSignal.timeout(5000),
        });

        if (upstreamRes.ok) {
          const data = await upstreamRes.json();
          res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=600');
          return res.status(200).json(data);
        }
      } catch {}
    }

    return res.status(502).json({
      success: false,
      error: 'Gagal memuat tayangan trending.',
      results: [],
    });
  }

  // Handle Discover Requests
  const type = (req.query.type as string) || 'movie';
  const genre = req.query.genre as string;
  const year = req.query.year as string;
  const minRating = req.query.min_rating as string;
  const sort = req.query.sort as string;
  const page = (req.query.page as string) || '1';

  if (type === 'anime') {
    const q = new URLSearchParams();
    q.set('page', page);
    if (genre && genre !== 'all') q.set('genre', genre);
    if (year && year !== 'all') q.set('year', year);

    for (const backend of backends) {
      try {
        const animeRes = await fetch(`${backend}/anime/api/discover?${q.toString()}`, {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            Referer: 'https://framextv.cc/',
            Origin: 'https://framextv.cc',
            Accept: 'application/json',
          },
          signal: AbortSignal.timeout(5000),
        });

        if (animeRes.ok) {
          const animeData = await animeRes.json();
          const items = Array.isArray(animeData.results) ? animeData.results : [];
          res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=600');
          return res.status(200).json({
            success: true,
            page: animeData.page || parseInt(page, 10),
            totalPages: animeData.totalPages || 50,
            totalResults: animeData.totalResults || items.length,
            results: items.map((a: any) => ({
              id: String(a.id),
              type: 'anime',
              title: a.title,
              poster: a.poster,
              backdrop: a.backdrop || a.poster,
              year: String(a.year || '2024'),
              rating: a.rating || '8.5',
              overview: a.synopsis || a.overview || 'Anime terpopuler di Zhafx.',
              genres: a.genres || ['Action', 'Fantasy'],
            })),
          });
        }
      } catch {}
    }
  }

  const q = new URLSearchParams();
  q.set('type', type);
  if (genre && genre !== 'all') q.set('genre', genre);
  if (year && year !== 'all') q.set('year', year);
  if (minRating) q.set('min_rating', minRating);
  if (sort) q.set('sort', sort);
  q.set('page', page);

  for (const backend of backends) {
    try {
      const upstreamRes = await fetch(`${backend}/api/discover?${q.toString()}`, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          Referer: 'https://framextv.cc/',
          Origin: 'https://framextv.cc',
          Accept: 'application/json',
        },
        signal: AbortSignal.timeout(5000),
      });

      if (upstreamRes.ok) {
        const data = await upstreamRes.json();
        res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=600');
        return res.status(200).json(data);
      }
    } catch {}
  }

  return res.status(502).json({
    success: false,
    error: 'Gagal memuat katalog film.',
    results: [],
  });
}

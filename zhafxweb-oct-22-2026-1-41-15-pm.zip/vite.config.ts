import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';
import { defineConfig } from 'vite';

const projectRootDir = typeof import.meta.dirname !== 'undefined'
  ? import.meta.dirname
  : path.dirname(fileURLToPath(import.meta.url));

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(projectRootDir, '.'),
      },
    },
    build: {
      chunkSizeWarningLimit: 600,
      rollupOptions: {
        output: {
          manualChunks: (id) => {
            if (id.includes('node_modules')) {
              if (id.includes('lucide-react') || id.includes('react-icons')) {
                return 'vendor-icons';
              }
              if (
                id.includes('react-markdown') ||
                id.includes('micromark') ||
                id.includes('remark') ||
                id.includes('unified') ||
                id.includes('unist') ||
                id.includes('mdast') ||
                id.includes('hast') ||
                id.includes('vfile') ||
                id.includes('bail') ||
                id.includes('trough')
              ) {
                return 'vendor-markdown';
              }
              if (id.includes('hls.js')) {
                return 'vendor-hls';
              }
              if (id.includes('motion') || id.includes('framer-motion') || id.includes('gsap')) {
                return 'vendor-animation';
              }
              if (
                id.includes('react-dom') ||
                id.includes('react-router') ||
                id.includes('/react/') ||
                id.endsWith('/react') ||
                id.includes('use-sync-external-store')
              ) {
                return 'vendor-react';
              }
              return 'vendor-core';
            }
          },
        },
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      allowedHosts: true,
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
